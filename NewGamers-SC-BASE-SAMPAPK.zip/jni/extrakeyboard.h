#pragma once

class CExtraKeyBoard
{
public:
	CExtraKeyBoard();
	~CExtraKeyBoard();

	void Render();
	void Clear();
	void Show(bool bShow);
	
private:
	bool 		m_bIsActive;
	bool 		m_bIsExtraShow;
};
