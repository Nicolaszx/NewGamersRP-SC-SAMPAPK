#include "main.h"
#include "gui/gui.h"
#include "chatwindow.h"
#include "keyboard.h"
#include "settings.h"
#include "game/game.h"
#include "net/netgame.h"
#include "dialog.h"

#include <time.h>
#include <cstdarg>

uint32_t		MAX_CHAT_MESSAGES = 40; // 8

static uint32_t dwLastUpdateTick = GetTickCount();
static uint32_t dwLastUpdateScrollTick = GetTickCount();
static float 	fChatScrollY = 0.0;
static float 	chatAlpha = 1.0f;

extern CGUI *pGUI;
extern CKeyBoard *pKeyBoard;
extern CSettings *pSettings;
extern CNetGame *pNetGame;
extern CGame *pGame;
extern CDialogWindow *pDialogWindow;

void TextWithColors(const char* fmt, ...);

std::unordered_map<std::string, CMDPROC> m_mapCmds;

void ChatWindowInputHandler(const char* str)
{
	if(!str || *str == '\0') return;
	if(!pNetGame) return;

	if(*str == '/')
	{
		char *szCmdEndPos = (char*)str + 1;
		while(*szCmdEndPos && *szCmdEndPos != ' ') szCmdEndPos++;
		if(*szCmdEndPos == '\0') {
			std::unordered_map<std::string, CMDPROC>::iterator cmd = m_mapCmds.find(str + 1);
			if(cmd != m_mapCmds.end())
			{
				cmd->second("");
			}
			else
			{
				if(pNetGame)
				{
					pNetGame->SendChatCommand(str);
				}
			}
		} 
		else 
		{
			char szCopiedBuffer[256];
			strcpy(szCopiedBuffer, str);

			*szCmdEndPos = '\0';
			szCmdEndPos++;

			std::unordered_map<std::string, CMDPROC>::iterator cmd = m_mapCmds.find(str + 1);
			if(cmd != m_mapCmds.end())
			{
				cmd->second(szCmdEndPos);
			}
			else
			{
				if(pNetGame)
				{
					pNetGame->SendChatCommand(szCopiedBuffer);
				}
			}
		}
	}
	else pNetGame->SendChatMessage(str);
	return;
}

CChatWindow::CChatWindow()
{
	m_fChatPosX = pGUI->ScaleX(pSettings->Get().fChatPosX);
	m_fChatPosY = pGUI->ScaleY(pSettings->Get().fChatPosY);

	m_fChatSizeX = pGUI->ScaleX(pSettings->Get().fChatSizeX);
	m_fChatSizeY = pGUI->ScaleY(pSettings->Get().fChatSizeY);

	m_iMaxMessages = pSettings->Get().iChatMaxMessages;

	Log("Chat pos: %f, %f, size: %f, %f", m_fChatPosX, m_fChatPosY, m_fChatSizeX, m_fChatSizeY);

	m_dwTextColor = 0xFFFFFFFF;
	m_dwInfoColor = 0x00C8C8FF;
	m_dwDebugColor = 0xBEBEBEFF;

	MAX_CHAT_MESSAGES = m_iMaxMessages*5;

	m_bIsOpened = false;
	m_iOffsetY = 0;

	ResetHiding();

	m_bShow = true;

	Log("Chat Window Initialized.");
}

CChatWindow::~CChatWindow() { }

bool CChatWindow::CheckScrollBar(int x, int y)
{
	float m_fSize = pGUI->GetFontSize();
	float scrollBarSize = m_ChatWindowEntries.size() * (MAX_CHAT_MESSAGES/m_iMaxMessages);

	if ( m_bIsOpened && x >= m_fChatPosX-pGUI->ScaleX(40.0f) && x <= m_fChatPosX-pGUI->ScaleX(3.0f) &&
		y >= m_fChatPosY + pGUI->ScaleY(scrollBarSize) + m_iOffsetY && y <= m_fChatPosY + m_fSize + m_iOffsetY )
	{
		m_bSwipeScroll = true;
		m_bIsOpened = true;
		return true;
	}
	return false;
}

void CChatWindow::OnExitFromInput()
{
	m_bIsOpened = false;
	m_bSwipeScroll = false;

	pGame->DisplayHUD(true);
	pGame->DisplayWidgets(true);

	m_fChatPosX = pGUI->ScaleX(pSettings->Get().fChatPosX);
	m_fChatSizeX = pGUI->ScaleX(pSettings->Get().fChatSizeX);
}

bool CChatWindow::OnTouchEvent(int type, bool multi, int x, int y)
{
	ImGuiIO& io = ImGui::GetIO();

	static bool bWannaOpenChat = false;

	float m_fSize = pGUI->GetFontSize();
	float scrollBarSize = m_ChatWindowEntries.size() * (MAX_CHAT_MESSAGES/m_iMaxMessages);

	switch(type)
	{
		case TOUCH_PUSH:
			if (m_bIsOpened && x >= m_fChatPosX-pGUI->ScaleX(40.0f) && x <= m_fChatPosX-pGUI->ScaleX(3.0f) &&
				y >= m_fChatPosY + pGUI->ScaleY(scrollBarSize) + m_iOffsetY &&
				y <= m_fChatPosY + m_fSize + m_iOffsetY )
			{
				m_bSwipeScroll = true;
				return true;
			}
			if(x >= m_fChatPosX && x <= m_fChatPosX + m_fChatSizeX &&
				y >= m_fChatPosY && y <= m_fChatPosY + m_fChatSizeY)
				bWannaOpenChat = true;
		break;

		case TOUCH_POP:
			if (m_bIsOpened && m_bSwipeScroll)
			{
				m_bSwipeScroll = false;

				return true;
			}
			if(bWannaOpenChat &&
				x >= m_fChatPosX && x <= m_fChatPosX + m_fChatSizeX &&
				y >= m_fChatPosY && y <= m_fChatPosY + m_fChatSizeY)
			{
				if(!pDialogWindow->m_bIsActive) //if(!(pDialogWindow->m_bIsActive == true && pDialogWindow->m_byteDialogStyle == DIALOG_STYLE_LIST))
				{
					m_bIsOpened = true;
					pKeyBoard->Open(&ChatWindowInputHandler);

					pGame->DisplayHUD(false);
					pGame->DisplayWidgets(false);

					m_fChatPosX = 20;
					m_fChatSizeX = io.DisplaySize.x - ImGui::GetFontSize() * 3;

					ResetHiding();
				}
			}
			bWannaOpenChat = false;
		break;

		case TOUCH_MOVE:
			if (m_bIsOpened && m_bSwipeScroll)
			{
				if(m_iLastPosY > y)
				{
					if( m_fChatPosY + pGUI->ScaleY(scrollBarSize) + m_iOffsetY > m_fChatPosY )
						m_iOffsetY -= 3;
				}
				if(m_iLastPosY < y)
				{
					if( m_fChatPosY + m_fSize + m_iOffsetY <= m_fChatPosY + m_fSize )
						m_iOffsetY += 3;
				}

				m_iLastPosY = y;
				return false;
			}
		break;
	}

	return true;
}

void CChatWindow::Render()
{
	if(!m_bShow) return; 
	if(ChatBoxShow) {

	m_fSize = pGUI->GetFontSize() * m_iMaxMessages;
	m_ivPos = ImVec2(m_fChatPosX, m_fChatPosY + m_fSize - pGUI->GetFontSize());

	/*ImGuiStyle* style = &ImGui::GetStyle();

	// ---> Set alpha -- -- -- -- --
	if(!m_bIsOpened && !pDialogWindow->m_bIsActive)
	{
		if(GetTickCount() - dwLastUpdateTick >= 50) // ---> One second timer -- -- -- -- --
		{
			dwLastUpdateTick = GetTickCount();
			m_iTime--;

			if (m_iTime <= 20)
			{
				style->Alpha -= 0.05;
			}
		}
	}*/
	// ---> Set alpha -- -- -- -- --

	ImGui::Begin("Chatwindow", (bool*)true, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings);

	ImGui::SetWindowPos(ImVec2(m_fChatPosX, m_fChatPosY));
	ImGui::SetWindowSize(ImVec2(m_fChatSizeX, m_fSize));

	std::list<CHAT_WINDOW_ENTRY>::iterator entry = m_ChatWindowEntries.begin();
	while(entry != m_ChatWindowEntries.end())
	{
		switch(entry->eType)
		{
			case CHAT_TYPE_CHAT:
				if(entry->szNick[0] != 0)
				{
					ImGui::PushFontOutline(0xFF000000, 2);
					ImGui::TextColored(ImColor(entry->dwNickColor), "%s", entry->szNick);
					ImGui::PopFontOutline();
					ImGui::SameLine();
				}

				ImGui::PushFontOutline(0xFF000000, 2);
				ImGui::PushStyleColor(ImGuiCol_Text, (ImVec4)ImColor(entry->dwTextColor));
				TextWithColors("%s", entry->utf8Message);
				ImGui::PopStyleColor();
				ImGui::PopFontOutline();
			break;

			case CHAT_TYPE_INFO:
			case CHAT_TYPE_DEBUG:
				ImGui::PushFontOutline(0xFF000000, 2);
				ImGui::PushStyleColor(ImGuiCol_Text, (ImVec4)ImColor(entry->dwTextColor));
				TextWithColors("%s", entry->utf8Message);
				ImGui::PopStyleColor();
				ImGui::PopFontOutline();
			break;
		}

		entry++;
	}

	if(GetTickCount() - dwLastUpdateScrollTick >= 10)
	{
		if(m_ChatWindowEntries.size() >= MAX_CHAT_MESSAGES)
		{
			m_ChatWindowEntries.pop_front();
			ImGui::SetScrollY(ImGui::GetScrollY() - fChatScrollY);
		}

		dwLastUpdateScrollTick = GetTickCount();
		if(ImGui::GetScrollY() == 0.0)
			ImGui::SetScrollY(ImGui::GetFontSize() / 2);
		else ImGui::SetScrollY(ImGui::GetScrollY() + ImGui::GetFontSize() / 10);

		fChatScrollY = ImGui::GetScrollY();
	}

	ImGui::End();
}
}

void CChatWindow::AddChatMessage(char* szNick, uint32_t dwNickColor, char* szMessage)
{
	ResetHiding();

	time_t rawtime;
	char buffffer[80];
	char mes[1024];

	m_iChatCount++;

	AddToChatWindowBuffer(CHAT_TYPE_CHAT, szMessage, szNick, m_dwTextColor, dwNickColor);
}

void CChatWindow::AddInfoMessage(const char* szFormat, ...)
{
	ResetHiding();
	
	char tmp_buf[512];
	memset(tmp_buf, 0, sizeof(tmp_buf));

	va_list args;
	va_start(args, szFormat);
	vsprintf(tmp_buf, szFormat, args);
	va_end(args);

	char buffer[80];

	FilterInvalidChars(tmp_buf);

	m_iChatCount++;

	AddToChatWindowBuffer(CHAT_TYPE_INFO, tmp_buf, nullptr, m_dwInfoColor, 0);
}

void CChatWindow::AddDebugMessage(const char* szFormat, ...)
{
	ResetHiding();
	
	char tmp_buf[512];
	memset(tmp_buf, 0, sizeof(tmp_buf));

	va_list args;
	va_start(args, szFormat);
	vsprintf(tmp_buf, szFormat, args);
	va_end(args);

	FilterInvalidChars(tmp_buf);

	m_iChatCount++;

	AddToChatWindowBuffer(CHAT_TYPE_DEBUG, tmp_buf, nullptr, m_dwDebugColor, 0);
}

void CChatWindow::AddClientMessage(uint32_t dwColor, char* szStr)
{
	ResetHiding();
	
	FilterInvalidChars(szStr);

	m_iChatCount++;
	
	AddToChatWindowBuffer(CHAT_TYPE_INFO, szStr, nullptr, dwColor, 0);
}

void CChatWindow::PushBack(CHAT_WINDOW_ENTRY &entry)
{
	if(m_ChatWindowEntries.size() >= MAX_CHAT_MESSAGES)
	{
		m_ChatWindowEntries.pop_front();
	}

	m_ChatWindowEntries.push_back(entry);
	return;
}

void CChatWindow::AddToChatWindowBuffer(eChatMessageType type, char* szString, char* szNick, uint32_t dwTextColor, uint32_t dwNickColor)
{
	int MAX_MESSAGES = 100;

	CHAT_WINDOW_ENTRY entry;
	entry.eType = type;
	entry.dwNickColor = __builtin_bswap32(dwNickColor | 0x000000FF);
	entry.dwTextColor = __builtin_bswap32(dwTextColor | 0x000000FF);

	if(szNick)
	{
		strcpy(entry.szNick, szNick);
		strcat(entry.szNick, ":");
	}
	else
		entry.szNick[0] = '\0';

	cp1251_to_utf8(entry.utf8Message, szString);

	m_iChatCount++;

	if(m_ChatWindowEntries.size() >= MAX_CHAT_MESSAGES)
		fChatScrollY += ImGui::GetFontSize() * 2;

	m_ChatWindowEntries.push_back(entry);
}

void CChatWindow::FilterInvalidChars(char* szString)
{
	while(*szString) 
	{
		if(*szString > 0 && *szString < ' ') 
			*szString = ' ';

		szString++;
	}
}

char* CChatWindow::TimeInMessage(char* szMessage)
{
	time_t rawtime;
	char buffer[80];

	struct tm* timeinfo;
	time(&rawtime);
	timeinfo = localtime(&rawtime);

	strftime(buffer, 80, "%H:%M:%S", timeinfo);
	
	char mes[1024];
	sprintf(mes, "[%d] %s", buffer, szMessage);

	return mes;
}

void CChatWindow::ResetHiding()
{
	ImGui::GetStyle().Alpha = 1.0f;
	m_iTime 				= 120;
	chatAlpha				= 1.0f;
	dwLastUpdateTick 		= GetTickCount();
}

void CChatWindow::AddCmdProc(const char *cmdname, CMDPROC cmdproc)
{
	m_mapCmds.insert(std::make_pair(cmdname, cmdproc));
}

void CChatWindow::DeleteCmdProc(const char *cmdname)
{
	std::unordered_map<std::string, CMDPROC>::iterator cmd = m_mapCmds.find(cmdname);
	if(cmd != m_mapCmds.end())
		m_mapCmds.erase(cmd);
}
