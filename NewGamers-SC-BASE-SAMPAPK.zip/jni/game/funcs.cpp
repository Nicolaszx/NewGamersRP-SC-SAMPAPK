#include "main.h"
#include "funcs.h"
#include "util/armhook.h"

void ToggleCJWalk(bool bUseCJWalk)
{
    if(bUseCJWalk)
        WriteMemory(g_libGTASA + 0x4C5EFA, (uintptr_t)"\xCA\xF8\xE0\x04", 4);
    else
        NOP(g_libGTASA + 0x4C5EFA, 2);
}