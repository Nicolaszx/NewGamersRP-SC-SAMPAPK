#pragma once

void ToggleCJWalk(bool bUseCJWalk);